//burn
{% load static %}
function changeStyle1(){
		var t=document.getElementById("img1").src="{% static 'team/burn2.jpg' %}";
}
function changeStyle2(){
		var t=document.getElementById("img1").src="burn.jpg";
}
//cancer
function changeStyle3(){
		var t=document.getElementById("img2").src="cancer2.jpg";
}
function changeStyle4(){
		var t=document.getElementById("img2").src="CANCER.jpeg";
}
//newborn
function changeStyle5(){
		var t=document.getElementById("img3").src="new2.jpg";
}
function changeStyle6(){
		var t=document.getElementById("img3").src="NEWBORN.jpg";
}
//kidney
function changeStyle7(){
		var t=document.getElementById("img4").src="kidney2.jpg";
}
function changeStyle8(){
		var t=document.getElementById("img4").src="kidney.jpeg";
}
//deficiency
function changeStyle9(){
		var t=document.getElementById("img5").src="deficiency1.jpg";
}
function changeStyle10(){
		var t=document.getElementById("img5").src="deficiency.jpg";
}

//hivAids
function changeStyle11(){
		var t=document.getElementById("img6").src=" hiv2.jpg";
}
function changeStyle12(){
		var t=document.getElementById("img6").src="HIV.jpg";
}
//diabetes
function changeStyle13(){
		var t=document.getElementById("img7").src="diabetes2.jpg";
}
function changeStyle14(){
		var t=document.getElementById("img7").src="diabetes.jpg";
}

//mental health
function changeStyle15(){
		var t=document.getElementById("img8").src="mental2.jpg";
}
function changeStyle16(){
		var t=document.getElementById("img8").src="MENTALHEALTH.png";
}
//leprosy
function changeStyle17(){
		var t=document.getElementById("img9").src="leprosy2.jpg";
}
function changeStyle18(){
		var t=document.getElementById("img9").src="LEPROSY.jpg";
}
//birth defect
function changeStyle19(){
		var t=document.getElementById("img10").src="birthdefect1.jpg";
}
function changeStyle20(){
		var t=document.getElementById("img10").src="birthdefect.jpeg";
}
//heart attack
function changeStyle21(){
		var t=document.getElementById("img11").src="heart1.jpg";
}
function changeStyle22(){
		var t=document.getElementById("img11").src="HEART.jpg";
}
//maternity
function changeStyle23(){
		var t=document.getElementById("img12").src="mater1.jpg";
}
function changeStyle24(){
		var t=document.getElementById("img12").src="MATERNITY.jpg";
}
//bone marrow
function changeStyle25(){
		var t=document.getElementById("img13").src="bone1.jpg";
}
function changeStyle26(){
		var t=document.getElementById("img13").src="bone-marrow.jpg";
}
//clinical test
function changeStyle27(){
		var t=document.getElementById("img14").src="clinical1.jpg";
}
function changeStyle28(){
		var t=document.getElementById("img14").src="clinicaltest.jpg";
}

//sanitary pads
function changeStyle29(){
		var t=document.getElementById("img15").src="sanitary1.jpg";
}
function changeStyle30(){
		var t=document.getElementById("img15").src="Sanitarypad.jpg";
}

//eyes
function changeStyle31(){
		var t=document.getElementById("img16").src="eyes1.jpg";
}
function changeStyle32(){
		var t=document.getElementById("img16").src="Eyes.jpg";
}

//polio
function changeStyle33(){
		var t=document.getElementById("img17").src="polio1.jpg";
}
function changeStyle34(){
		var t=document.getElementById("img17").src="POLIO.jpeg";
}


//lungs
function changeStyle35(){
		var t=document.getElementById("img18").src="lungs1.jpg";
}
function changeStyle36(){
		var t=document.getElementById("img18").src="Lungs.jpg";
}
//urinary test
function changeStyle37(){
		var t=document.getElementById("img19").src="urinary1.jpg";
}
function changeStyle38(){
		var t=document.getElementById("img19").src="Urinary.jpg";
}
//brain
function changeStyle39(){
		var t=document.getElementById("img20").src="brain1.jpg";
}
function changeStyle40(){
		var t=document.getElementById("img20").src="Brain.jpg";
}
//tb
function changeStyle41(){
		var t=document.getElementById("img21").src="tb1.jpg";
}
function changeStyle42(){
		var t=document.getElementById("img21").src="TB.jpg";
}

//fertility
function changeStyle43(){
		var t=document.getElementById("img22").src="fertility1.jpg";
}
function changeStyle44(){
		var t=document.getElementById("img22").src="Fertility.jpg";
}
//joint
function changeStyle45(){
		var t=document.getElementById("img23").src="joints1.jpg";
}
function changeStyle46(){
		var t=document.getElementById("img23").src="Joints.jpg";
}
//health  insurance
function changeStyle47(){
		var t=document.getElementById("img24").src="health1.jpg";
}
function changeStyle48(){
		var t=document.getElementById("img24").src="health.jpg";
}
//vector Born disease
function changeStyle49(){
		var t=document.getElementById("img25").src="vector1.jpg";
}
function changeStyle50(){
		var t=document.getElementById("img25").src="vector.jpg";
}
//accident
function changeStyle51(){
		var t=document.getElementById("img26").src="accident1.jpg";
}
function changeStyle52(){
		var t=document.getElementById("img26").src="accident.png";
}

//casual diseasae
function changeStyle53(){
		var t=document.getElementById("img27").src="casual1.png";
}
function changeStyle54(){
		var t=document.getElementById("img27").src="casual.png";
}

//life threatening
function changeStyle55(){
		var t=document.getElementById("img28").src="life1.jpg";
}
function changeStyle56(){
		var t=document.getElementById("img28").src="Life.jpg";
}

//non communicable
function changeStyle57(){
		var t=document.getElementById("img29").src="non1.jpg";
}
function changeStyle58(){
		var t=document.getElementById("img29").src="Non.png";
}

//plastic surgery
function changeStyle59(){
		var t=document.getElementById("img30").src="plastic1.jpg";
}
function changeStyle60(){
		var t=document.getElementById("img30").src="plastic.png";
}

//ortho
function changeStyle61(){
		var t=document.getElementById("img31").src="ortho1.jpg";
}
function changeStyle62(){
		var t=document.getElementById("img31").src="ortho.png";
}

//disability
function changeStyle63(){
		var t=document.getElementById("img32").src="vector1.jpg";
}
function changeStyle64(){
		var t=document.getElementById("img32").src="Disability.png";
}

//plague
function changeStyle65(){
		var t=document.getElementById("img33").src="vector1.jpg";
}
function changeStyle66(){
		var t=document.getElementById("img33").src="vector.jpg";
}
